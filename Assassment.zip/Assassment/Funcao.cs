using System;
using EntidadeBiblioteca;

namespace FilmesBiblioteca{
    public class Funcao : IFilmesFuncao{
        
    }
}