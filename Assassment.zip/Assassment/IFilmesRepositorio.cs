using System;


namespace FilmesBiblioteca{
    public interface IFilmesFuncao{
     
    }
}
